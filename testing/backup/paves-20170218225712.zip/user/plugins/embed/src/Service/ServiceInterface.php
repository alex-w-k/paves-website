<?php

namespace Gertt\Grav\Embed\Service;

interface ServiceInterface
{
	public function embed($data);
}
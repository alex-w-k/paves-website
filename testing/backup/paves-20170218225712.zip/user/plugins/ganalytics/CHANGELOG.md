# v1.2.0
## 11/08/2016

1. [](#new)    
    * Rename the Global (ga) Object
    * Use the debug version of GA + Trace Debugging
        
# v1.1.0
## 02/08/2016

1. [](#new)
    * Anonymize the IP address of all hits

# v1.0.0
## 11/08/2015

1. [](#new)
    * GA Plugin started

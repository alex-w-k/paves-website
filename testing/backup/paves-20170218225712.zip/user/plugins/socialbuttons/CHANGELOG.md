# v1.0.3
## 11/16/2015

1. [](#improved)
    * Social button label is now configurable by the plugin's configuration file

# v1.0.2
## 09/01/2015

1. [](#improved)
    * Configured the plugin to work with Admin Panel
    
# v0.9.0
## 08/06/2015

1. [](#new)
    * Plugin started

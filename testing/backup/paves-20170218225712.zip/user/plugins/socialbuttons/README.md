# Grav Social Buttons Plugin

`Social Buttons` is a [Grav](http://github.com/getgrav/grav) Plugin and allows to display social buttons, everywhere on your website.

The full ducumentation is available at the [developer's website](http://diblas.net/plugins/social-buttons-grav-cms-plugin-renders-the-rrssb-social-buttons-icons)
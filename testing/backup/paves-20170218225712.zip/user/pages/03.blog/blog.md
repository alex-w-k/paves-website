---
title: Blog
metadata:
    description: 'What we are doing at PAVES!'
slug: blog
content:
    items: '@self.children'
    order:
        by: date
        dir: desc
    limit: 10
    pagination: true
feed:
    description: 'All the stuff we find important'
    limit: 10
pagination: true
---

# PAVES Blog
Stay up to date with all the things PAVES is currently working on. 

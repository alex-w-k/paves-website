---
cache_enable: false
visible: false
---

---
visible: false
cache_enable: false
---

[g-navbar id="navbar1" name=navbar1 fixed=top centering=none brand_text="PAVES" render=false]
    [g-navbar-menu name=menu0 alignment="center" submenu="internal,components" attributes="class:highdensity-menu"][/g-navbar-menu]    
    [g-navbar-menu name=menu1 icon_type="fontawesome" alignment="right" ]
        [g-link url="https://facebook.com/PAVESnonprofit" icon_type="fontawesome" icon="facebook"][/g-link]
        [g-link url="https://twitter.com/pavesnonprofit" icon="twitter"][/g-link]
    [/g-navbar-menu]
[/g-navbar]

[g-footer-two name="footer" render=false]
[g-section name="mission" attributes="class:col-md-6"]

The mission of PAVES is to, through outreach and awareness campaigns, ensure that polysexual individuals know they are not forgotten and are never alone.

[/g-section]

[g-section name="donate" attributes="class:col-md-6"]
**Support us!**<br>
Paypal Donate button goes **here**<br>
Google Wallet Donate button goes **here**<br>
[/g-section]
[g-section name="copyright"]PAVES[/g-section]


[/g-footer-two]
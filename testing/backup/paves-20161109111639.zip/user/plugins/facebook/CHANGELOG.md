# v1.0.2
## 11/08/2016

1. [](#bugfix)
  * Update plugin version number in the blueprints

2. [](#improved)
    * Update README to reflect plugin HTML output example

# v1.0.1
## 11/04/2016

1. [](#improved)
  * Changed plugin icon to Facebook icon

2. [](#improved)
  * Moved post images after post message

# v1.0.0
## 10/20/2016

1. [](#new)
  * ChangeLog started...

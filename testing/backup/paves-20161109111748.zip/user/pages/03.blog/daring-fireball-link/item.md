---
title: 'Just Some Text Today'
date: '13:34 07/10/2014'
taxonomy:
    category:
        - blog
    tag:
        - journal
        - link
    author:
        - 'Other Author'
continue_link: true
link: 'http://daringfireball.net'
---

The blog skeleton also supports **Daring Fireball** style link posts.  Simply add a link setting in your page header:

```
link: http://daringfireball.net
```

And your blog title becomes a link directly to that link you specified. Easy peasy!


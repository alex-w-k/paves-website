---
title: 'Test of new blog'
date: '19-10-2016 15:44'
taxonomy:
    category:
        - blog
    tag:
        - test
    author:
        - 'Alex Koch'
---

Test post please ignore.